<?php
// Heading
$_['heading_title']    = 'TM Cookie Policy';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified TM Cookie Policy module!';
$_['text_edit']        = 'Edit TM Cookie Policy Module';

// Entry
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify TM Cookie Policy module!';